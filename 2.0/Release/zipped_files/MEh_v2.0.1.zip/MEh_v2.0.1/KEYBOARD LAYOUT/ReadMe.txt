===============================================================================

MEh Keyboard Layout Installer ReadMe File

===============================================================================

This Installer was created with the Microsoft Keyboard Layout Creator 1.4.
The source file used to create this installer was "MEh_2.0.klc".
This tool is very old and buggy. Be aware !

===============================================================================

To install this layout into a Windows operating system:

1.	Unpack the installer somewhere to a persistent storage.

2.	Run the "setup.exe" file.

3.	Log out of your Windows 10 O.S. and log in again.

===============================================================================

To uninstall this layout from a Windows operating system:

1.	Uninstall the layout as a standard Windows' application from the control 
	panel.

2.	Delete the "MEh_Keyb.dll" file from following system folders:
	2.1.	<OS_DRIVE>:\Windows\System32
	2.2.	<OS_DRIVE>:\Windows\SysWOW64
	<OS_DRIVE> is the letter of the system's drive, "C" in most cases.

===============================================================================
